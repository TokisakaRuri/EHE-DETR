import os, sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../../..')
import warnings
warnings.filterwarnings('ignore')
from calflops import calculate_flops
import torch, math
import torch.nn as nn
import torch.nn.functional as F
from engine.extre_module.ultralytics_nn.conv import Conv
from engine.extre_module.ultralytics_nn.block import C3, C2f
__all__ = ['DSConv_YOLO13', 'DSC3k2', 'HyperACE', 'DownsampleConv', 'FullPAD_Tunnel']

class DSConv_YOLO13(nn.Module):

    def __init__(self, c_in, c_out, k=3, s=1, p=None, d=1, bias=False):
        super().__init__()
        if p is None:
            p = d * (k - 1) // 2
        self.dw = nn.Conv2d(c_in, c_in, kernel_size=k, stride=s, padding=p, dilation=d, groups=c_in, bias=bias)
        self.pw = nn.Conv2d(c_in, c_out, 1, 1, 0, bias=bias)
        self.bn = nn.BatchNorm2d(c_out)
        self.act = nn.SiLU()

    def forward(self, x):
        x = self.dw(x)
        x = self.pw(x)
        return self.act(self.bn(x))

class DSBottleneck(nn.Module):

    def __init__(self, c1, c2, shortcut=True, e=0.5, k1=3, k2=5, d2=1):
        super().__init__()
        c_ = int(c2 * e)
        self.cv1 = DSConv_YOLO13(c1, c_, k1, s=1, p=None, d=1)
        self.cv2 = DSConv_YOLO13(c_, c2, k2, s=1, p=None, d=d2)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        y = self.cv2(self.cv1(x))
        return x + y if self.add else y

class DSC3k(C3):

    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5, k1=3, k2=5, d2=1):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = nn.Sequential(*(DSBottleneck(c_, c_, shortcut=shortcut, e=1.0, k1=k1, k2=k2, d2=d2) for _ in range(n)))

class DSC3k2(C2f):

    def __init__(self, c1, c2, n=1, dsc3k=False, e=0.5, g=1, shortcut=True, k1=3, k2=7, d2=1):
        super().__init__(c1, c2, n, shortcut, g, e)
        if dsc3k:
            self.m = nn.ModuleList((DSC3k(self.c, self.c, n=2, shortcut=shortcut, g=g, e=1.0, k1=k1, k2=k2, d2=d2) for _ in range(n)))
        else:
            self.m = nn.ModuleList((DSBottleneck(self.c, self.c, shortcut=shortcut, e=1.0, k1=k1, k2=k2, d2=d2) for _ in range(n)))

class AdaHyperedgeGen(nn.Module):

    def __init__(self, node_dim, num_hyperedges, num_heads=4, dropout=0.1, context='both'):
        super().__init__()
        self.num_heads = num_heads
        self.num_hyperedges = num_hyperedges
        self.head_dim = node_dim // num_heads
        self.context = context
        self.prototype_base = nn.Parameter(torch.Tensor(num_hyperedges, node_dim))
        nn.init.xavier_uniform_(self.prototype_base)
        if context in ('mean', 'max'):
            self.context_net = nn.Linear(node_dim, num_hyperedges * node_dim)
        elif context == 'both':
            self.context_net = nn.Linear(2 * node_dim, num_hyperedges * node_dim)
        else:
            raise ValueError(f"Unsupported context '{context}'. Expected one of: 'mean', 'max', 'both'.")
        self.pre_head_proj = nn.Linear(node_dim, node_dim)
        self.dropout = nn.Dropout(dropout)
        self.scaling = math.sqrt(self.head_dim)

    def forward(self, X):
        (B, N, D) = X.shape
        if self.context == 'mean':
            context_cat = X.mean(dim=1)
        elif self.context == 'max':
            (context_cat, _) = X.max(dim=1)
        else:
            avg_context = X.mean(dim=1)
            (max_context, _) = X.max(dim=1)
            context_cat = torch.cat([avg_context, max_context], dim=-1)
        prototype_offsets = self.context_net(context_cat).view(B, self.num_hyperedges, D)
        prototypes = self.prototype_base.unsqueeze(0) + prototype_offsets
        X_proj = self.pre_head_proj(X)
        X_heads = X_proj.view(B, N, self.num_heads, self.head_dim).transpose(1, 2)
        proto_heads = prototypes.view(B, self.num_hyperedges, self.num_heads, self.head_dim).permute(0, 2, 1, 3)
        X_heads_flat = X_heads.reshape(B * self.num_heads, N, self.head_dim)
        proto_heads_flat = proto_heads.reshape(B * self.num_heads, self.num_hyperedges, self.head_dim).transpose(1, 2)
        logits = torch.bmm(X_heads_flat, proto_heads_flat) / self.scaling
        logits = logits.view(B, self.num_heads, N, self.num_hyperedges).mean(dim=1)
        logits = self.dropout(logits)
        return F.softmax(logits, dim=1)

class AdaHGConv(nn.Module):

    def __init__(self, embed_dim, num_hyperedges=16, num_heads=4, dropout=0.1, context='both'):
        super().__init__()
        self.edge_generator = AdaHyperedgeGen(embed_dim, num_hyperedges, num_heads, dropout, context)
        self.edge_proj = nn.Sequential(nn.Linear(embed_dim, embed_dim), nn.GELU())
        self.node_proj = nn.Sequential(nn.Linear(embed_dim, embed_dim), nn.GELU())

    def forward(self, X):
        A = self.edge_generator(X)
        He = torch.bmm(A.transpose(1, 2), X)
        He = self.edge_proj(He)
        X_new = torch.bmm(A, He)
        X_new = self.node_proj(X_new)
        return X_new + X

class AdaHGComputation(nn.Module):

    def __init__(self, embed_dim, num_hyperedges=16, num_heads=8, dropout=0.1, context='both'):
        super().__init__()
        self.embed_dim = embed_dim
        self.hgnn = AdaHGConv(embed_dim=embed_dim, num_hyperedges=num_hyperedges, num_heads=num_heads, dropout=dropout, context=context)

    def forward(self, x):
        (B, C, H, W) = x.shape
        tokens = x.flatten(2).transpose(1, 2)
        tokens = self.hgnn(tokens)
        x_out = tokens.transpose(1, 2).view(B, C, H, W)
        return x_out

class C3AH(nn.Module):

    def __init__(self, c1, c2, e=1.0, num_hyperedges=8, context='both'):
        super().__init__()
        c_ = int(c2 * e)
        assert c_ % 16 == 0, 'Dimension of AdaHGComputation should be a multiple of 16.'
        num_heads = c_ // 16
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.m = AdaHGComputation(embed_dim=c_, num_hyperedges=num_hyperedges, num_heads=num_heads, dropout=0.1, context=context)
        self.cv3 = Conv(2 * c_, c2, 1)

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), 1))

class FuseModule(nn.Module):

    def __init__(self, c_in, channel_adjust):
        super(FuseModule, self).__init__()
        self.downsample = nn.AvgPool2d(kernel_size=2)
        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')
        if channel_adjust:
            self.conv_out = Conv(4 * c_in, c_in, 1)
        else:
            self.conv_out = Conv(3 * c_in, c_in, 1)

    def forward(self, x):
        x1_ds = self.downsample(x[0])
        x3_up = self.upsample(x[2])
        x_cat = torch.cat([x1_ds, x[1], x3_up], dim=1)
        out = self.conv_out(x_cat)
        return out

class HyperACE(nn.Module):

    def __init__(self, c1, c2, n=1, num_hyperedges=8, dsc3k=True, shortcut=False, e1=0.5, e2=1, context='both', channel_adjust=False):
        super().__init__()
        self.c = int(c2 * e1)
        self.cv1 = Conv(c1, 3 * self.c, 1, 1)
        self.cv2 = Conv((4 + n) * self.c, c2, 1)
        self.m = nn.ModuleList((DSC3k(self.c, self.c, 2, shortcut, k1=3, k2=7) if dsc3k else DSBottleneck(self.c, self.c, shortcut=shortcut) for _ in range(n)))
        self.fuse = FuseModule(c1, channel_adjust)
        self.branch1 = C3AH(self.c, self.c, e2, num_hyperedges, context)
        self.branch2 = C3AH(self.c, self.c, e2, num_hyperedges, context)

    def forward(self, X):
        x = self.fuse(X)
        y = list(self.cv1(x).chunk(3, 1))
        out1 = self.branch1(y[1])
        out2 = self.branch2(y[1])
        y.extend((m(y[-1]) for m in self.m))
        y[1] = out1
        y.append(out2)
        return self.cv2(torch.cat(y, 1))

class DownsampleConv(nn.Module):

    def __init__(self, in_channels, channel_adjust=False):
        super().__init__()
        self.downsample = nn.AvgPool2d(kernel_size=2)
        if channel_adjust:
            self.channel_adjust = Conv(in_channels, in_channels * 2, 1)
        else:
            self.channel_adjust = nn.Identity()

    def forward(self, x):
        return self.channel_adjust(self.downsample(x))

class FullPAD_Tunnel(nn.Module):

    def __init__(self):
        super().__init__()
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x):
        out = x[0] + self.gate * x[1]
        return out
if __name__ == '__main__':
    (RED, GREEN, BLUE, YELLOW, ORANGE, RESET) = ('\x1b[91m', '\x1b[92m', '\x1b[94m', '\x1b[93m', '\x1b[38;5;208m', '\x1b[0m')
    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
    (batch_size, channel, height, width) = (1, 128, 20, 20)
    inputs_P3 = torch.randn((batch_size, channel, height * 4, width * 4)).to(device)
    inputs_P4 = torch.randn((batch_size, channel, height * 2, width * 2)).to(device)
    inputs_P5 = torch.randn((batch_size, channel, height, width)).to(device)
    print(RED + '-' * 20 + ' HyperACE ' + '-' * 20 + RESET)
    feats = [inputs_P3, inputs_P4, inputs_P5]
    module = HyperACE(channel, channel, n=1, num_hyperedges=8, dsc3k=True, shortcut=True, channel_adjust=False).to(device)
    outputs = module(feats)
    print(GREEN + f'inputs_P3.size:{inputs_P3.size()} inputs_P4.size:{inputs_P4.size()} inputs_P5.size:{inputs_P5.size()} outputs.size:{outputs.size()}' + RESET)
    print(ORANGE)
    (flops, macs, _) = calculate_flops(model=module, args=[feats], output_as_string=True, output_precision=4, print_detailed=True)
    print(RESET)
    print(RED + '-' * 20 + ' FullPAD_Tunnel ' + '-' * 20 + RESET)
    inputs_1 = torch.randn((batch_size, channel, height, width)).to(device)
    inputs_2 = torch.randn((batch_size, channel, height, width)).to(device)
    feats = [inputs_1, inputs_2]
    module = FullPAD_Tunnel().to(device)
    outputs = module(feats)
    print(GREEN + f'inputs_1.size:{inputs_1.size()} inputs_2.size:{inputs_2.size()} outputs.size:{outputs.size()}' + RESET)
    print(ORANGE)
    (flops, macs, _) = calculate_flops(model=module, args=[feats], output_as_string=True, output_precision=4, print_detailed=True)
    print(RESET)
    print(RED + '-' * 20 + ' DownsampleConv ' + '-' * 20 + RESET)
    inputs = torch.randn((batch_size, channel, height, width)).to(device)
    module = DownsampleConv(channel).to(device)
    outputs = module(inputs)
    print(GREEN + f'inputs.size:{inputs.size()} outputs.size:{outputs.size()}' + RESET)
    print(ORANGE)
    (flops, macs, _) = calculate_flops(model=module, input_shape=(batch_size, channel, height, width), output_as_string=True, output_precision=4, print_detailed=True)
    print(RESET)
