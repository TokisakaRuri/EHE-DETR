import os, sys
import math
import json
import numpy as np
from typing import Iterable
from tqdm import tqdm
from prettytable import PrettyTable
from tidecv import TIDE, datasets
import torch
import torch.amp
from torch.utils.tensorboard import SummaryWriter
from torch.cuda.amp.grad_scaler import GradScaler
from ..optim import ModelEMA, Warmup
from ..data import CocoEvaluator
from ..misc import MetricLogger, MetricLogger_progress, SmoothedValue, dist_utils, plot_sample
from ..extre_module.ops import Profile
from ..extre_module.utils import TQDM, RANK
from ..extre_module.yolo_metrice import get_yolo_metrice
TIME_DEBUG = False
(RED, GREEN, BLUE, YELLOW, ORANGE, RESET) = ('\x1b[91m', '\x1b[92m', '\x1b[94m', '\x1b[93m', '\x1b[38;5;208m', '\x1b[0m')

def train_one_epoch(self_lr_scheduler, lr_scheduler, model: torch.nn.Module, criterion: torch.nn.Module, data_loader: Iterable, optimizer: torch.optim.Optimizer, device: torch.device, epoch: int, max_norm: float=0, **kwargs):
    model.train()
    criterion.train()
    print_freq = kwargs.get('print_freq', 10)
    writer: SummaryWriter = kwargs.get('writer', None)
    ema: ModelEMA = kwargs.get('ema', None)
    scaler: GradScaler = kwargs.get('scaler', None)
    lr_warmup_scheduler: Warmup = kwargs.get('lr_warmup_scheduler', None)
    plot_train_batch_freq = kwargs.get('plot_train_batch_freq', 12)
    output_dir = kwargs.get('output_dir', None)
    epoches = kwargs.get('epoches', -1)
    verbose_type = kwargs.get('verbose_type', 'origin')
    header = 'Epoch: {}/{}'.format(epoch, epoches)
    cur_iters = epoch * len(data_loader)
    if verbose_type == 'origin':
        metric_logger = MetricLogger(delimiter='  ')
    else:
        metric_logger = MetricLogger_progress(delimiter='  ')
    metric_logger.add_meter('lr', SmoothedValue(window_size=1, fmt='{value:.6f}'))
    pbar = enumerate(metric_logger.log_every(data_loader, print_freq if verbose_type == 'origin' else 1, header))
    dt = [Profile(device=device), Profile(device=device), Profile(device=device), Profile(device=device), Profile(device=device)]
    for (i, (samples, targets)) in pbar:
        if epoch % plot_train_batch_freq == 0 and i == 0:
            if data_loader.dataset.remap_mscoco_category:
                plot_sample((samples, targets), data_loader.dataset.category2name, output_dir / f'train_batch_{epoch}.png', data_loader.dataset.label2category)
            else:
                plot_sample((samples, targets), data_loader.dataset.category2name, output_dir / f'train_batch_{epoch}.png')
        with dt[0]:
            samples = samples.to(device, non_blocking=True)
            targets = [{k: v.to(device, non_blocking=True) for (k, v) in t.items()} for t in targets]
        global_step = epoch * len(data_loader) + i
        metas = dict(epoch=epoch, step=i, global_step=global_step, epoch_step=len(data_loader))
        if scaler is not None:
            with dt[1]:
                with torch.autocast(device_type=str(device), cache_enabled=True):
                    outputs = model(samples, targets=targets)
            if torch.isnan(outputs['pred_boxes']).any() or torch.isinf(outputs['pred_boxes']).any():
                print(outputs['pred_boxes'])
                state = model.state_dict()
                new_state = {}
                for (key, value) in model.state_dict().items():
                    new_key = key.replace('module.', '')
                    state[new_key] = value
                new_state['model'] = state
                dist_utils.save_on_master(new_state, './NaN.pth')
            with dt[2]:
                with torch.autocast(device_type=str(device), enabled=False):
                    loss_dict = criterion(outputs, targets, **metas)
                loss = sum(loss_dict.values())
            with dt[3]:
                scaler.scale(loss).backward()
                if max_norm > 0:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()
        else:
            with dt[1]:
                outputs = model(samples, targets=targets)
            with dt[2]:
                loss_dict = criterion(outputs, targets, **metas)
                loss: torch.Tensor = sum(loss_dict.values())
            with dt[3]:
                optimizer.zero_grad()
                loss.backward()
                if max_norm > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)
                optimizer.step()
        with dt[4]:
            if ema is not None:
                ema.update(model)
            if self_lr_scheduler:
                optimizer = lr_scheduler.step(cur_iters + i, optimizer)
            elif lr_warmup_scheduler is not None:
                lr_warmup_scheduler.step()
            loss_dict_reduced = dist_utils.reduce_dict(loss_dict)
            loss_value = sum(loss_dict_reduced.values())
            if not math.isfinite(loss_value):
                print('Loss is {}, stopping training'.format(loss_value))
                print(loss_dict_reduced)
                sys.exit(1)
            metric_logger.update(loss=loss_value, **loss_dict_reduced)
            metric_logger.update(lr=optimizer.param_groups[0]['lr'])
            if writer and dist_utils.is_main_process() and (global_step % 10 == 0):
                writer.add_scalar('Loss/total', loss_value.item(), global_step)
                for (j, pg) in enumerate(optimizer.param_groups):
                    writer.add_scalar(f'Lr/pg_{j}', pg['lr'], global_step)
                for (k, v) in loss_dict_reduced.items():
                    writer.add_scalar(f'Loss/{k}', v.item(), global_step)
    metric_logger.synchronize_between_processes()
    print(GREEN, 'Averaged stats:', metric_logger, RESET)
    if TIME_DEBUG:
        time_data = [x.t / len(data_loader) for x in dt]
        print(RED + f'Data_to_Device:{time_data[0]:.6f}s Inference:{time_data[1]:.6f}s Loss:{time_data[2]:.6f}s Weight_Update:{time_data[3]:.6f}s' + RESET)
    return {k: meter.global_avg for (k, meter) in metric_logger.meters.items()}

@torch.no_grad()
def evaluate(model: torch.nn.Module, criterion: torch.nn.Module, postprocessor, data_loader, coco_evaluator: CocoEvaluator, device, test_only=False, output_dir=None, yolo_metrice=False):
    model.eval()
    criterion.eval()
    coco_evaluator.cleanup()
    metric_logger = MetricLogger_progress(delimiter='  ')
    header = 'Test:'
    iou_types = coco_evaluator.iou_types
    dt = [Profile(device=device), Profile(device=device)]
    coco_pred_json = []
    for (samples, targets) in metric_logger.log_every(data_loader, 1, header):
        samples = samples.to(device, non_blocking=True)
        targets = [{k: v.to(device, non_blocking=True) for (k, v) in t.items()} for t in targets]
        with dt[0]:
            outputs = model(samples)
        orig_target_sizes = torch.stack([t['orig_size'] for t in targets], dim=0)
        with dt[1]:
            results = postprocessor(outputs, orig_target_sizes)
        res = {target['image_id'].item(): output for (target, output) in zip(targets, results)}
        if coco_evaluator is not None:
            coco_evaluator.update(res)
            coco_pred_json.extend(list(coco_evaluator.coco_eval['bbox'].cocoDt.anns.values()))
    metric_logger.synchronize_between_processes()
    print(GREEN + 'Averaged stats:', metric_logger)
    if coco_evaluator is not None:
        coco_evaluator.synchronize_between_processes()
    if test_only:
        speed = dict(zip(['inference', 'postprocess'], (x.t / len(data_loader.dataset) * 1000.0 for x in dt)))
        print('-' * 20, f'Test On BatchSize:{data_loader.batch_size}', '-' * 20)
        print('-' * 20, f"Speed: {speed['inference']:.4f}ms inference, {speed['postprocess']:.4f}ms postprocess per image", '-' * 20)
        print('-' * 20, f"FPS(inference+postprocess): {1000 / (speed['inference'] + speed['postprocess']):.2f}", '-' * 20)
    if yolo_metrice:
        get_yolo_metrice(coco_evaluator, coco_pred_json)
    if coco_evaluator is not None:
        print(RED + '------------------------ COCO Metrice Start ------------------------' + ORANGE)
        coco_evaluator.accumulate()
        coco_evaluator.summarize()
        if test_only:
            print(ORANGE + f"Saving coco pred[{output_dir / 'pred.json'}] json...")
            with open(output_dir / 'pred.json', 'w') as f:
                json.dump(coco_pred_json, f)
            print('save success.')
            precisions = coco_evaluator.coco_eval['bbox'].eval['precision']
            cat_ids = coco_evaluator.coco_eval['bbox'].params.cat_ids
            results_per_category = []
            for (idx, cat_id) in enumerate(cat_ids):
                t = []
                nm = coco_evaluator.coco_gt.cats[cat_id]
                precision = precisions[:, :, idx, 0, -1]
                precision = precision[precision > -1]
                if precision.size:
                    ap = np.mean(precision)
                else:
                    ap = float('nan')
                t.append(f"{nm['name']}")
                t.append(f'{round(ap, 3)}')
                for iou in [0, 5]:
                    precision = precisions[iou, :, idx, 0, -1]
                    precision = precision[precision > -1]
                    if precision.size:
                        ap = np.mean(precision)
                    else:
                        ap = float('nan')
                    t.append(f'{round(ap, 3)}')
                for area in [1, 2, 3]:
                    precision = precisions[:, :, idx, area, -1]
                    precision = precision[precision > -1]
                    if precision.size:
                        ap = np.mean(precision)
                    else:
                        ap = float('nan')
                    t.append(f'{round(ap, 3)}')
                results_per_category.append(list(t))
            model_metrice_table = PrettyTable()
            model_metrice_table.title = 'COCO Metrice'
            model_metrice_table.field_names = ['category', 'AP', 'AP_50', 'AP_75', 'AP_s', 'AP_m', 'AP_l']
            for data in results_per_category:
                model_metrice_table.add_row(list(data))
            numeric_data = [list(data)[1:] for data in results_per_category]
            avg_values = []
            for col_idx in range(len(numeric_data[0])):
                col_values = [float(row[col_idx]) for row in numeric_data if float(row[col_idx]) is not None]
                if col_values:
                    avg_value = sum(col_values) / len(col_values)
                    avg_values.append(round(avg_value, 3))
                else:
                    avg_values.append(0.0)
            all_row = ['all'] + avg_values
            model_metrice_table.add_row(all_row)
            print(model_metrice_table)
            try:
                print(RED + '------------------------ TIDE Metrice Start ------------------------' + ORANGE)
                tide = TIDE()
                tide.evaluate_range(datasets.COCO(data_loader.dataset.ann_file), datasets.COCOResult(output_dir / 'pred.json'))
                tide.summarize()
                tide.plot(out_dir=output_dir / 'tide_result')
            except Exception as e:
                print(RED, 'TIDE failure... skip message:', e)
    print(RESET)
    stats = {}
    if coco_evaluator is not None:
        if 'bbox' in iou_types:
            stats['coco_eval_bbox'] = coco_evaluator.coco_eval['bbox'].stats.tolist()
        if 'segm' in iou_types:
            stats['coco_eval_masks'] = coco_evaluator.coco_eval['segm'].stats.tolist()
        if hasattr(coco_evaluator, 'evaluate_crowdhuman'):
            crowdhuman_stats = coco_evaluator.evaluate_crowdhuman(output_dir)
            if 'crowdhuman_eval' in crowdhuman_stats:
                stats['crowdhuman_eval'] = crowdhuman_stats['crowdhuman_eval']
    return (stats, coco_evaluator)
